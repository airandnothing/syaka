<?php

/**
 * Translation
 */
load_textdomain('tcd-w', dirname(__FILE__).'/languages/tcd-iconic-' . determine_locale() . '.mo');
load_textdomain('tcd-iconic', dirname(__FILE__).'/languages/tcd-iconic-' . determine_locale() . '.mo');

// style.cssのDescriptionをPoedit等に認識させる
__( '"ICONIC" is a WordPress theme for online stores that is compatible with Welcart. It builds a minimalistic e-commerce site that highlights your products. And some banner contents promote your products from any angles.', 'tcd-iconic' );

/**
 * Theme setup
 */
function iconic_setup() {
	// Post thumbnails
	add_theme_support( 'post-thumbnails' );

	// Title tag
	add_theme_support( 'title-tag' );

	// Image sizes
	add_image_size( 'size1', 300, 300, true );
	add_image_size( 'size2', 500, 500, true );
	add_image_size( 'size3', 740, 460, true );
	add_image_size( 'size4', 740, 540, true );
	add_image_size( 'size5', 1200, 0, false );
	add_image_size( 'size-card', 300, 300, true ); // カードリンクパーツ用

	// imgタグのsrcsetを未使用に
	add_filter( 'wp_calculate_image_srcset', '__return_false' );

	// Menu
	register_nav_menus( array(
		'global' => __( 'Global menu', 'tcd-w' )
	) );
}
add_action( 'after_setup_theme', 'iconic_setup' );

/**
 * Theme init
 */
function iconic_init() {
	global $dp_options;
	if ( ! $dp_options ) $dp_options = get_design_plus_option();

	disable_emoji();
	
	// カスタム投稿 お知らせ
	register_post_type( $dp_options['news_slug'], array(
		'label' => $dp_options['news_breadcrumb_label'],
		'labels' => array(
			'name' => $dp_options['news_breadcrumb_label'],
			'singular_name' => $dp_options['news_breadcrumb_label'],
			'add_new' => __( 'Add New', 'tcd-w' ),
			'add_new_item' => __( 'Add New Item', 'tcd-w' ),
			'edit_item' => __( 'Edit', 'tcd-w' ),
			'new_item' => __( 'New item', 'tcd-w' ),
			'view_item' => __( 'View Item', 'tcd-w' ),
			'search_items' => __( 'Search Items', 'tcd-w' ),
			'not_found' => __( 'Not Found', 'tcd-w' ),
			'not_found_in_trash' => __( 'Not found in trash', 'tcd-w' ),
			'parent_item_colon' => ''
		),
		'public' => true,
		'publicly_queryable' => true,
		'menu_position' => 5,
		'show_ui' => true,
		'query_var' => true,
		'rewrite' => true,
		'capability_type' => 'post',
		'has_archive' => true,
		'hierarchical' => false,
		'show_in_rest' => true,
		'supports' => array( 'title', 'editor', 'thumbnail' )
	) );
}
add_action( 'init', 'iconic_init' );

function disable_emoji() {
	$options = get_design_plus_option();
	if ( $options['use_emoji'] == 0 ) {

		// remove inline script
		remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
		// remove inline style
		remove_action( 'wp_print_styles', 'print_emoji_styles' );
		// remove inline style  6.4 later
		if ( function_exists( 'wp_enqueue_emoji_styles' ) ) {
		remove_action( 'wp_enqueue_scripts', 'wp_enqueue_emoji_styles' );
		remove_action( 'admin_enqueue_scripts', 'wp_enqueue_emoji_styles' );
		}

		// initだと早いため、admin_initで実行
		add_action( 'admin_init', function(){
		// remove inline script
		remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
		// remove inline style
		remove_action( 'admin_print_styles', 'print_emoji_styles' );
		// remove inline style 6.4 later
		if ( function_exists( 'wp_enqueue_emoji_styles' ) ) {
			remove_action( 'admin_enqueue_scripts', 'wp_enqueue_emoji_styles' );
		}
		} );

	}
}


/**
 * Theme scripts and style
 */
function iconic_scripts() {
	global $dp_options;
	if ( ! $dp_options ) $dp_options = get_design_plus_option();

	// usces_cart.cssはwelcartから自動で読み込まれます
	// get_stylesheet_directory_uri() . '/usces_cart.css' のため子テーマ時はコピーや@import等が必要

	// slick読み込みフラグ
	$slick_load = false;

	if ( is_front_page() ) {
		$slick_load = true;
		wp_enqueue_script( 'iconic-front-page', get_template_directory_uri() . '/js/front-page.js', array( 'jquery' ), version_num(), true );
	}

	// 共通
	wp_enqueue_style( 'iconic-style', get_stylesheet_uri(), array(), version_num() );
	wp_enqueue_script( 'iconic-script', get_template_directory_uri() . '/js/functions.js', array( 'jquery' ), version_num(), true );

	// TCDCE対策のため、クイックタグスタイルをstyle.cssから分離させる
	// NOTE: スタイルの優先度に影響を与えないよう、style.cssの直後に読み込み
	wp_enqueue_style( 'design-plus', get_template_directory_uri() . '/css/design-plus.css', array(), version_num() );

	// slick
	if ( $slick_load ) {
		wp_enqueue_script( 'iconic-slick', get_template_directory_uri() . '/js/slick.min.js', array( 'jquery' ), version_num(), true );
		wp_enqueue_style( 'iconic-slick', get_template_directory_uri() . '/css/slick.min.css' );

		// ページビルダーのslick.js,slick.cssを読み込まないように
		add_filter( 'page_builder_slick_enqueue_script', '__return_false' );
		add_filter( 'page_builder_slick_enqueue_style', '__return_false' );
	}

	// フッターバー
	if ( is_mobile() && 'type3' !== $dp_options['footer_bar_display'] ) {
		wp_enqueue_style( 'iconic-footer-bar', get_template_directory_uri() . '/css/footer-bar.css', false, version_num() );
		wp_enqueue_script( 'iconic-footer-bar', get_template_directory_uri() . '/js/footer-bar.js', array( 'jquery' ), version_num(), true );
	}

	// ヘッダースクロール
	if ( 'type2' == $dp_options['header_fix'] || 'type2' == $dp_options['mobile_header_fix'] ) {
		wp_enqueue_script( 'iconic-header-fix', get_template_directory_uri() . '/js/header-fix.js', array( 'jquery' ), version_num(), true );
	}

	// comment
	if ( is_single() && comments_open() ) {
		wp_enqueue_script( 'comment-reply' );
		wp_enqueue_script( 'iconic-comment', get_template_directory_uri() . '/js/comment.js', array(), version_num() );
	}
	
	// 共通
	wp_enqueue_style( 'tcd-sns-style', get_template_directory_uri() . '/css/sns-button.css', array(), version_num() );
	
	// アドミンバーのインラインスタイルを出力しない
	remove_action( 'wp_head', '_admin_bar_bump_cb' );
	remove_action( 'wp_head', 'wp_admin_bar_header' );
	remove_action( 'wp_enqueue_scripts', 'wp_enqueue_admin_bar_bump_styles' );
	remove_action( 'wp_enqueue_scripts', 'wp_enqueue_admin_bar_header_styles' );
}
add_action( 'wp_enqueue_scripts', 'iconic_scripts' );

function iconic_admin_scripts() {
	// 管理画面共通
	wp_enqueue_style( 'tcd_admin_css', get_template_directory_uri() . '/admin/css/tcd_admin.css', array(), version_num() );
	wp_enqueue_script( 'tcd_script', get_template_directory_uri() . '/admin/js/tcd_script.js', array(), version_num() );
	wp_enqueue_script('font_ui', get_template_directory_uri().'/admin/font/ui/font_ui.js', '', '1.0.4', true);
	wp_enqueue_style('font_ui_css', get_template_directory_uri() . '/admin/font/ui/font_ui.css','','1.0.0');
	wp_localize_script( 'tcd_script', 'TCD_MESSAGES', array(
		'ajaxSubmitSuccess' => __( 'Settings Saved Successfully', 'tcd-w' ),
		'ajaxSubmitError' => __( 'Can not save data. Please try again.', 'tcd-w' )
	) );

	// 画像アップロードで使用
	wp_enqueue_script( 'cf-media-field', get_template_directory_uri() . '/admin/js/cf-media-field.js', array( 'media-upload' ), version_num() );
	wp_localize_script( 'cf-media-field', 'cfmf_text', array(
		'image_title' => __( 'Please Select Image', 'tcd-w' ),
		'image_button' => __( 'Use this Image', 'tcd-w' ),
		'video_title' => __( 'Please Select Video', 'tcd-w' ),
		'video_button' => __( 'Use this Video', 'tcd-w' )
	) );

	// メディアアップローダーAPIを利用するための処理 Welcart商品ページは除外
    if ( ! isset( $_GET['page'] ) || ( $_GET['page'] != 'usces_itemedit' && $_GET['page'] != 'usces_itemnew' ) ) {
        wp_enqueue_media();
    }
    
	// ウィジェットで使用
	wp_enqueue_script( 'iconic-widget-script', get_template_directory_uri() . '/admin/js/widget.js', array( 'jquery' ), version_num() );

	// テーマオプションのタブで使用
	wp_enqueue_script( 'jquery.cookieTab', get_template_directory_uri() . '/admin/js/jquery.cookieTab.js', array(), version_num() );

	// テーマオプションのAJAX保存で使用
	wp_enqueue_script( 'jquery-form' );

	// フッターバー
	wp_enqueue_style( 'iconic-admin-footer-bar', get_template_directory_uri() . '/admin/css/footer-bar.css', array(), version_num() );
	wp_enqueue_script( 'iconic-admin-footer-bar', get_template_directory_uri() . '/admin/js/footer-bar.js', array(), version_num() );

	// WPカラーピッカー
	wp_enqueue_style( 'wp-color-picker' );
	wp_enqueue_script( 'wp-color-picker' );
}
add_action( 'admin_enqueue_scripts', 'iconic_admin_scripts' );

// 埋め込みコンテンツのレスポンシブ化
add_theme_support( 'responsive-embeds' );

// 各サムネイル画像生成時の品質を82→90に
function iconic_wp_editor_set_quality( $quality, $mime_type ) {
	return 90;
}
add_filter( 'wp_editor_set_quality', 'iconic_wp_editor_set_quality', 10, 2 );

// Widget area
function iconic_widgets_init() {
	// Common side widget
	register_sidebar( array(
		'before_widget' => '<div class="p-widget p-widget-sidebar %2$s" id="%1$s">' . "\n",
		'after_widget' => "</div>\n",
		'before_title' => '<div class="p-widget__title">',
		'after_title' => '</div>' . "\n",
		'name' => __( 'Common side widget', 'tcd-w' ),
        'description' => __('Widgets set in this widget area are displayed as "basic widget" in the sidebar of all pages. If there are individual settings, the widget will be displayed.', 'tcd-w'),
		'id' => 'common_side_widget'
	) );

	// Post side widget
	register_sidebar( array(
		'before_widget' => '<div class="p-widget p-widget-sidebar %2$s" id="%1$s">' . "\n",
		'after_widget' => "</div>\n",
		'before_title' => '<div class="p-widget__title">',
		'after_title' => '</div>' . "\n",
		'name' => __( 'Post side widget', 'tcd-w' ),
		'id' => 'post_side_widget'
	) );

	// News side widget
	register_sidebar( array(
		'before_widget' => '<div class="p-widget p-widget-sidebar %2$s" id="%1$s">' . "\n",
		'after_widget' => "</div>\n",
		'before_title' => '<div class="p-widget__title">',
		'after_title' => '</div>' . "\n",
		'name' => __( 'News side widget', 'tcd-w' ),
		'id' => 'news_side_widget'
	) );

	// Page side widget
	register_sidebar( array(
		'before_widget' => '<div class="p-widget p-widget-sidebar %2$s" id="%1$s">' . "\n",
		'after_widget' => "</div>\n",
		'before_title' => '<div class="p-widget__title">',
		'after_title' => '</div>' . "\n",
		'name' => __( 'Page side widget', 'tcd-w' ),
		'id' => 'page_side_widget'
	) );

	// Welcart side widget
	register_sidebar( array(
		'before_widget' => '<div class="p-widget p-widget-sidebar %2$s" id="%1$s">' . "\n",
		'after_widget' => "</div>\n",
		'before_title' => '<div class="p-widget__title">',
		'after_title' => '</div>' . "\n",
		'name' => __( 'Welcart side widget', 'tcd-w' ),
		'id' => 'welcart_side_widget'
	) );

	// Footer
	register_sidebar( array(
		'before_widget' => '<div class="p-widget p-widget-footer %2$s" id="%1$s">' . "\n",
		'after_widget' => "</div>\n",
		'before_title' => '<div class="p-widget__title">',
		'after_title' => '</div>' . "\n",
		'name' => __( 'Footer widget', 'tcd-w' ),
		'id' => 'footer_widget'
	) );

	// Post side widget (mobile)
	register_sidebar( array(
		'before_widget' => '<div class="p-widget p-widget-sidebar %2$s" id="%1$s">' . "\n",
		'after_widget' => "</div>\n",
		'before_title' => '<div class="p-widget__title">',
		'after_title' => '</div>' . "\n",
		'name' => __( 'Post side widget (mobile)', 'tcd-w' ),
		'id' => 'post_side_widget_mobile'
	) );

	// News side widget (mobile)
	register_sidebar( array(
		'before_widget' => '<div class="p-widget p-widget-sidebar %2$s" id="%1$s">' . "\n",
		'after_widget' => "</div>\n",
		'before_title' => '<div class="p-widget__title">',
		'after_title' => '</div>' . "\n",
		'name' => __( 'News side widget (mobile)', 'tcd-w' ),
		'id' => 'news_side_widget_mobile'
	) );

	// Page side widget (mobile)
	register_sidebar( array(
		'before_widget' => '<div class="p-widget p-widget-sidebar %2$s" id="%1$s">' . "\n",
		'after_widget' => "</div>\n",
		'before_title' => '<div class="p-widget__title">',
		'after_title' => '</div>' . "\n",
		'name' => __( 'Page side widget (mobile)', 'tcd-w' ),
		'id' => 'page_side_widget_mobile'
	) );

	// Welcart side widget (mobile)
	register_sidebar( array(
		'before_widget' => '<div class="p-widget p-widget-sidebar %2$s" id="%1$s">' . "\n",
		'after_widget' => "</div>\n",
		'before_title' => '<div class="p-widget__title">',
		'after_title' => '</div>' . "\n",
		'name' => __( 'Welcart side widget (mobile)', 'tcd-w' ),
		'id' => 'welcart_side_widget_mobile'
	) );

	// Footer (mobile)
	register_sidebar( array(
		'before_widget' => '<div class="p-widget p-widget-footer %2$s" id="%1$s">' . "\n",
		'after_widget' => "</div>\n",
		'before_title' => '<div class="p-widget__title">',
		'after_title' => '</div>' . "\n",
		'name' => __( 'Footer widget (mobile)', 'tcd-w' ),
		'id' => 'footer_widget_mobile'
	) );
}
add_action( 'widgets_init', 'iconic_widgets_init' );

/**
 * get active sidebar
 */
function get_active_sidebar() {
	global $post, $dp_options;
	if ( ! $dp_options ) $dp_options = get_design_plus_option();

	$sidebars = array();

	if ( is_front_page() || is_home() ) {
		return false;

	} elseif ( is_welcart_archive() || is_welcart_single() || is_welcart_search_page() ) {
		if ( is_mobile() ) {
			$sidebars[] = 'welcart_side_widget_mobile';
		} else {
			$sidebars[] = 'welcart_side_widget';
		}

	} elseif ( is_welcart_page() ) {
		return false;

	} elseif ( ( is_post_type_archive( $dp_options['news_slug'] ) || is_singular( $dp_options['news_slug'] ) ) ) {
		if ( is_mobile() ) {
			$sidebars[] = 'news_side_widget_mobile';
		} else {
			$sidebars[] = 'news_side_widget';
		}

	} elseif ( is_archive() ) {
		return false;

	} elseif ( is_page() ) {
		if ( 'show' == $post->display_side_content ) {
			if ( is_mobile() ) {
				$sidebars[] = 'page_side_widget_mobile';
			} else {
				$sidebars[] = 'page_side_widget';
			}
		}

	} elseif ( is_singular() ) {
		if ( is_mobile() ) {
			$sidebars[] = 'post_side_widget_mobile';
		} else {
			$sidebars[] = 'post_side_widget';
		}
	}

	if ( ! empty( $sidebars ) ) {
		$sidebars[] = 'common_side_widget';

		foreach( $sidebars as $sidebar ) {
			if ( is_active_sidebar( $sidebar ) ) {
				return $sidebar;
			}
		}
	}

	return false;
}

/**
 * body class
 */
function iconic_body_classes( $classes ) {
	global $dp_options;
	if ( ! $dp_options ) $dp_options = get_design_plus_option();

	if ( is_welcart_single() ) {
		$classes[] = 'single-item';
	}

	if ( get_active_sidebar() ) {
		if ( is_welcart_archive() || is_welcart_single() || is_welcart_page() ) {
			$classes[] = 'l-sidebar--' . $dp_options['sidebar_welcart'];
		} else {
			$classes[] = 'l-sidebar--' . $dp_options['sidebar'];
		}
	}

	if ( $dp_options['header_fix'] == 'type2' && !wp_is_mobile() ) {
		$classes[] = 'l-header__fix';
	}

	if ( $dp_options['mobile_header_fix'] == 'type2' && wp_is_mobile() ) {
		$classes[] = 'l-header__fix l-header__fix--mobile';
	}
	
	if( is_404() || (is_search() && ( !have_posts() || empty( get_search_query() ))) )  { $classes[] = 'hide_contents'; };

	return array_unique( $classes );
}
add_filter( 'body_class', 'iconic_body_classes' );

/**
 * Excerpt
 */
function custom_excerpt_length( $length = null ) {
	return 64;
}
add_filter( 'excerpt_length', 'custom_excerpt_length', 999 );

function custom_excerpt_more( $more = null ) {
	return '...';
}
add_filter( 'excerpt_more', 'custom_excerpt_more' );

/**
 * Remove wpautop from the excerpt
 */
remove_filter( 'the_excerpt', 'wpautop' );

/**
 * Customize archive title
 */
function iconic_archive_title( $title ) {
	global $author, $post;
	if ( is_author() ) {
		$title = get_the_author_meta( 'display_name', $author );
	} elseif ( is_category() || is_tag() ) {
		$title = single_term_title( '', false );
	} elseif ( is_day() ) {
		$title = get_the_time( __( 'F jS, Y', 'tcd-w' ), $post );
	} elseif ( is_month() ) {
		$title = get_the_time( __( 'F, Y', 'tcd-w' ), $post );
	} elseif ( is_year() ) {
		$title = get_the_time( __( 'Y', 'tcd-w' ), $post );
	} elseif ( is_search() ) {
		$title = __( 'Search result', 'tcd-w' );
	}
	return $title;
}
add_filter( 'get_the_archive_title', 'iconic_archive_title', 10 );

/**
 * Translate Hex to RGB
 */
function hex2rgb( $hex ) {
	$hex = str_replace( '#', '', $hex );

	if ( strlen( $hex ) == 3 ) {
		$r = hexdec( substr( $hex, 0, 1 ) . substr( $hex, 0, 1 ) );
		$g = hexdec( substr( $hex, 1, 1 ) . substr( $hex, 1, 1 ) );
		$b = hexdec( substr( $hex, 2, 1 ) . substr( $hex, 2, 1 ) );
	} else {
		$r = hexdec( substr( $hex, 0, 2 ) );
		$g = hexdec( substr( $hex, 2, 2 ) );
		$b = hexdec( substr( $hex, 4, 2 ) );
	}

	return array( $r, $g, $b );
}

/**
 * ユーザーエージェントを判定するための関数
 */
function is_mobile() {
    if ( isset( $_SERVER['HTTP_SEC_CH_UA_MOBILE'] ) ) {
        $is_mobile = ( '?1' === $_SERVER['HTTP_SEC_CH_UA_MOBILE'] );
    } elseif ( empty( $_SERVER['HTTP_USER_AGENT'] ) ) {
        $is_mobile = false;
    } elseif (
        (str_contains( $_SERVER['HTTP_USER_AGENT'], 'Mobile' ) && !str_contains( $_SERVER['HTTP_USER_AGENT'], 'iPad' )) // iPad を除外
        || (str_contains( $_SERVER['HTTP_USER_AGENT'], 'Android' ) && !str_contains( $_SERVER['HTTP_USER_AGENT'], 'Tablet' )) // Android タブレットを除外
        || str_contains( $_SERVER['HTTP_USER_AGENT'], 'iPhone' ) // iPhone を明示的に含む
        || str_contains( $_SERVER['HTTP_USER_AGENT'], 'BlackBerry' )
        || str_contains( $_SERVER['HTTP_USER_AGENT'], 'Opera Mini' )
        || str_contains( $_SERVER['HTTP_USER_AGENT'], 'Opera Mobi' )
    ) {
        $is_mobile = true;
    } else {
        $is_mobile = false;
    }
  
  return $is_mobile;

}

/**
 * レスポンシブOFF機能を判定するための関数
 */
function is_no_responsive() {
	return false;
}

/**
 * スクリプトのバージョン管理
 */
function version_num() {
	static $theme_version = null;

	if ( $theme_version !== null ) {
		return $theme_version;
	}

	if ( function_exists( 'wp_get_theme' ) ) {
		$theme_data = wp_get_theme( get_template() );
	} else {
		$theme_data = get_theme_data( TEMPLATEPATH . '/style.css' );
	}

	if ( isset( $theme_data['Version'] ) ) {
		$theme_version = $theme_data['Version'];
	} else {
		$theme_version = '';
	}

	return $theme_version;
}


/**
 * カスタムコメント
 */
function custom_comments( $comment, $args, $depth ) {
	$GLOBALS['comment'] = $comment;
	global $commentcount;
	if ( ! $commentcount ) {
		$commentcount = 0;
	}
?>
<li id="comment-<?php comment_ID(); ?>" class="c-comment__list-item comment">
	<div class="c-comment__item-header u-clearfix">
		<div class="c-comment__item-meta u-clearfix">
<?php
	if ( function_exists( 'get_avatar' ) && get_option( 'show_avatars' ) ) {
		echo get_avatar( $comment, 35, '', false, array( 'class' => 'c-comment__item-avatar' ) );
	}
	if ( get_comment_author_url() ) {
		echo '<a id="commentauthor-' . get_comment_ID() . '" class="c-comment__item-author" rel="nofollow">' . get_comment_author() . '</a>' . "\n";
	} else {
		echo '<span id="commentauthor-' . get_comment_ID() . '" class="c-comment__item-author">' . get_comment_author() . '</span>' . "\n";
	}
?>
			<time class="c-comment__item-date" datetime="<?php comment_time( 'c' ); ?>"><?php comment_time( __( 'F jS, Y', 'tcd-w' ) ); ?></time>
		</div>
		<ul class="c-comment__item-act">
<?php
	if ( 1 == get_option( 'thread_comments' ) ) :
?>
			<li><?php comment_reply_link( array_merge( $args, array( 'add_below' => 'comment-content', 'depth' => $depth, 'max_depth' => $args['max_depth'], 'reply_text' => __( 'REPLY', 'tcd-w' ) . '' ) ) ); ?></li>
<?php
	else :
?>
			<li><a href="javascript:void(0);" onclick="MGJS_CMT.reply('commentauthor-<?php comment_ID(); ?>', 'comment-<?php comment_ID(); ?>', 'js-comment__textarea');"><?php _e( 'REPLY', 'tcd-w' ); ?></a></li>
<?php
	endif;
?>
		<li><a href="javascript:void(0);" onclick="MGJS_CMT.quote('commentauthor-<?php comment_ID(); ?>', 'comment-<?php comment_ID(); ?>', 'comment-content-<?php comment_ID(); ?>', 'js-comment__textarea');"><?php _e( 'QUOTE', 'tcd-w' ); ?></a></li>
		<?php edit_comment_link( __( 'EDIT', 'tcd-w' ), '<li>', '</li>'); ?>
		</ul>
	</div>
	<div id="comment-content-<?php comment_ID(); ?>" class="c-comment__item-body">
<?php
	if ( 0 == $comment->comment_approved ) {
		echo '<span class="c-comment__item-note">' . __( 'Your comment is awaiting moderation.', 'tcd-w' ) . '</span>' . "\n";
	} else {
		comment_text();
	}
?>
	</div>
<?php
}

// News 表示件数
function pre_get_posts_news( $wp_query ) {
	global $dp_options;
	if ( ! $dp_options ) $dp_options = get_design_plus_option();

	if ( ! is_admin() && $wp_query->is_main_query() && $wp_query->is_post_type_archive( $dp_options['news_slug'] ) && 0 < $dp_options['archive_news_num'] ) {
		$wp_query->set( 'posts_per_page', $dp_options['archive_news_num'] );
	}
}
add_filter( 'pre_get_posts', 'pre_get_posts_news' );

// Theme options
get_template_part( 'admin/theme-options' );
get_template_part( 'admin/theme-options-tools' );

// Contents Builder
get_template_part( 'admin/contents-builder' );

// Add custom columns
get_template_part( 'functions/admin_column' );

// Category custom fields
get_template_part( 'functions/category' );

// Custom CSS
get_template_part( 'functions/custom_css' );

// Add quicktags to the visual editor
get_template_part( 'functions/custom_editor' );

// hook wp_head
get_template_part( 'functions/head' );

// Mega menu
get_template_part( 'functions/megamenu' );

// OGP
get_template_part( 'functions/ogp' );

// Recommend post
get_template_part( 'functions/recommend' );

// Page builder
get_template_part( 'pagebuilder/pagebuilder' );

// Post custom fields
get_template_part( 'functions/post_cf' );

// Page custom fields
get_template_part( 'functions/page_cf' );
get_template_part( 'functions/page_cf2' );
// Password protected pages
get_template_part( 'functions/password_form' );

// Show custom fields in quick edit
get_template_part( 'functions/quick_edit' );

// Meta title and description
get_template_part( 'functions/seo' );

// Shortcode
get_template_part( 'functions/short_code' );

// セットアップ -------------------------------------------------------------------------------
require_once ( dirname(__FILE__) . '/functions/theme-setup.php' );

// Update notifier
get_template_part( 'functions/update_notifier' );

// Manual
get_template_part( 'functions/manual' );

// カスタマイザー設定( 外観 > ウィジェットから設定を取り除く)
get_template_part( 'functions/customizer' );

// 「トップページ」と「ブログ一覧ページ」用の固定ページ作成機能の実装
require_once  ( dirname(__FILE__) . '/functions/class-page-new.php' );

// 新フォント機能 --------------------------------------------------------------------------------
require_once ( dirname(__FILE__) . '/admin/font/hooks-font.php' );

// Welcart
get_template_part( 'functions/welcart' );
get_template_part( 'functions/welcart_cf' );

// Widgets
get_template_part( 'widget/ad' );
get_template_part( 'widget/archive_list' );
get_template_part( 'widget/category_list' );
get_template_part( 'widget/google_search' );
get_template_part( 'widget/item_category' );
get_template_part( 'widget/site_info' );
get_template_part( 'widget/styled_post_list_tab' );

// Card link
get_template_part( 'functions/card-link' );


// ウィジェットブロックエディターを無効化 --------------------------------------------------------------------------------
function exclude_theme_support() {
    remove_theme_support( 'widgets-block-editor' );
}
add_action( 'after_setup_theme', 'exclude_theme_support' );


// 月別アーカイブから商品記事のみ公開の月を除去
add_filter('getarchives_where', 'welcart_getarchives_where');
function welcart_getarchives_where( $r ){
	$where = "WHERE post_type = 'post' AND post_status = 'publish' AND post_mime_type <> 'item' ";
	return $where;
}

// 指定色から淡い色を作る --------------------------------------------------------------------------------
function lightness( $hexCode, $adjustPercent ) {
    $hexCode = ltrim( $hexCode, '#' );
    if ( strlen( $hexCode ) == 3 ) {
        $hexCode = $hexCode[0] . $hexCode[0] . $hexCode[1] . $hexCode[1] . $hexCode[2] . $hexCode[2];
    }
    $hexCode = array_map( 'hexdec', str_split( $hexCode, 2 ) );
    foreach ( $hexCode as & $color ) {
        $adjustableLimit = $adjustPercent < 0 ? $color : 255 - $color;
        $adjustAmount = ceil( $adjustableLimit * $adjustPercent );
        $color = str_pad( dechex( $color + $adjustAmount ), 2, '0', STR_PAD_LEFT );
    }
    return '#' . implode( $hexCode );
}

/**
 * PWAプラグイン未インストール時のメッセージ
 *
 * NOTE: TCDユーザーがPWAプラグインを知る・使うための導線を作るために用意
 */
add_action( 'admin_notices', 'tcd_pwa_admin_notice' );
function tcd_pwa_admin_notice(){
  global $plugin_page;

  // テーマオプションページ以外では表示しない
  if( $plugin_page !== 'theme_options' ){
    return;
  }

  // TCD PWA が有効化されていれば表示しない
  if( defined( 'TCDPWA_ACTIVE' ) && TCDPWA_ACTIVE ){
    return;
  }

  // チェックしたいプラグインのメインファイルを指定
  $target_plugin_file = 'tcd-pwa/tcd-pwa.php';

  // すべてのインストール済みプラグインを取得
  $installed_plugins = get_plugins();

  // インストール済みなら終了
  if( isset( $installed_plugins[$target_plugin_file] ) ){
    return;
  }

  // notice作成
  printf(
    '<div class="notice notice-info is-dismissible">
      <p>%1$s</p>
      <p>
        <a class="button" href="%2$s" target="_blank">%3$s</a>
        <a class="button button-primary" href="%4$s" target="_blank">%5$s</a>
      </p>
    </div>',
    // TCDテーマをPWA化できるプラグイン「TCD Progressive Web Apps」を利用できます。
    __( 'The TCD Progressive Web Apps plugin is available to convert TCD themes into PWAs.','tcd-w'  ),
    // 解説記事URL
    'https://tcd-theme.com/2025/05/tcd-pwa.html',
    // 設定・使い方
    __( 'Settings/How to use','tcd-w'  ),
    // マイページの商品URL
    'https://tcd.style/order-history?pname=TCD+Progressive+Web+Apps',
    // 今すぐインストール
    __( 'Install Now','tcd-w' )
  );
}
